# Core configuration and security
